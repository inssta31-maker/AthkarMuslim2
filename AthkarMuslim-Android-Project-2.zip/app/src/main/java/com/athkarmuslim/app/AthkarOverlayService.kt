package com.athkarmuslim.app

import android.app.*
import android.content.Intent
import android.graphics.Color
import android.graphics.PixelFormat
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.view.Gravity
import android.view.MotionEvent
import android.view.WindowManager
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Button
import android.graphics.Typeface

class AthkarOverlayService : Service() {
    companion object {
        const val ACTION_START = "com.athkarmuslim.START"
        const val ACTION_UPDATE = "com.athkarmuslim.UPDATE"
        private const val CHANNEL = "athkar_overlay"
        private const val NOTIFICATION_ID = 41
    }
    private val handler = Handler(Looper.getMainLooper())
    private var windowManager: WindowManager? = null
    private var overlay: LinearLayout? = null
    private var params: WindowManager.LayoutParams? = null
    private var index = 0
    private val prefs by lazy { getSharedPreferences("athkar_settings", MODE_PRIVATE) }
    private val adhkar = listOf(
        "سُبْحَانَ اللَّهِ وَبِحَمْدِهِ",
        "أَسْتَغْفِرُ اللَّهَ وَأَتُوبُ إِلَيْهِ",
        "لَا إِلَهَ إِلَّا اللَّهُ وَحْدَهُ لَا شَرِيكَ لَهُ",
        "اللَّهُمَّ صَلِّ وَسَلِّمْ عَلَى نَبِيِّنَا مُحَمَّدٍ",
        "سُبْحَانَ اللَّهِ الْعَظِيمِ"
    )
    private val ticker = object : Runnable {
        override fun run() {
            if (!prefs.getBoolean("enabled", false)) { stopSelf(); return }
            showNext()
            val minutes = prefs.getInt("interval", 10).coerceIn(1, 60)
            handler.postDelayed(this, minutes * 60_000L)
        }
    }

    override fun onCreate() {
        super.onCreate()
        windowManager = getSystemService(WINDOW_SERVICE) as WindowManager
        createChannel()
        startForeground(NOTIFICATION_ID, notification())
        showNext()
        schedule()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_UPDATE) schedule()
        if (intent?.action == ACTION_START) schedule()
        return START_STICKY
    }

    private fun schedule() {
        handler.removeCallbacks(ticker)
        val minutes = prefs.getInt("interval", 10).coerceIn(1, 60)
        handler.postDelayed(ticker, minutes * 60_000L)
    }

    private fun showNext() {
        if (!android.provider.Settings.canDrawOverlays(this)) { stopSelf(); return }
        val text = adhkar[index % adhkar.size]
        index++
        if (overlay == null) createOverlay()
        val label = overlay?.findViewWithTag<TextView>("zikr")
        label?.text = text
        overlay?.let { view ->
            try {
                if (view.parent == null) windowManager?.addView(view, params)
            } catch (_: Exception) { }
        }
    }

    private fun createOverlay() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(22, 16, 22, 12)
            setBackgroundColor(Color.rgb(18, 34, 58))
            elevation = 12f
        }
        val close = TextView(this).apply {
            text = "✕"
            textSize = 16f
            setTextColor(Color.rgb(220, 190, 120))
            gravity = Gravity.END
            setPadding(0, 0, 0, 6)
            setOnClickListener { removeOverlay() }
        }
        root.addView(close)
        val text = TextView(this).apply {
            tag = "zikr"
            textSize = 19f
            gravity = Gravity.CENTER
            setTextColor(Color.WHITE)
            typeface = Typeface.DEFAULT_BOLD
            setPadding(8, 8, 8, 8)
        }
        root.addView(text)
        val lp = WindowManager.LayoutParams(
            WindowManager.LayoutParams.MATCH_PARENT.coerceAtMost(resources.displayMetrics.widthPixels - 48),
            WindowManager.LayoutParams.WRAP_CONTENT,
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY else WindowManager.LayoutParams.TYPE_PHONE,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT
        )
        lp.gravity = Gravity.TOP or Gravity.CENTER_HORIZONTAL
        lp.y = 90
        var startX = 0f
        var startY = 0f
        var initialX = 0
        var initialY = 0
        root.setOnTouchListener { _, event ->
            when (event.action) {
                MotionEvent.ACTION_DOWN -> {
                    startX = event.rawX; startY = event.rawY
                    initialX = lp.x; initialY = lp.y
                    true
                }
                MotionEvent.ACTION_MOVE -> {
                    lp.x = initialX + (event.rawX - startX).toInt()
                    lp.y = initialY + (event.rawY - startY).toInt()
                    try { windowManager?.updateViewLayout(root, lp) } catch (_: Exception) {}
                    true
                }
                else -> false
            }
        }
        overlay = root
        params = lp
    }

    private fun removeOverlay() {
        overlay?.let { try { windowManager?.removeView(it) } catch (_: Exception) {} }
        overlay = null
    }

    private fun createChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(CHANNEL, "الأذكار العائمة", NotificationManager.IMPORTANCE_LOW)
            getSystemService(NotificationManager::class.java).createNotificationChannel(channel)
        }
    }
    private fun notification(): Notification {
        val pending = PendingIntent.getActivity(this, 0, Intent(this, MainActivity::class.java), PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            Notification.Builder(this, CHANNEL).setContentTitle("أذكار مسلم").setContentText("الأذكار العائمة تعمل").setSmallIcon(android.R.drawable.ic_dialog_info).setContentIntent(pending).build()
        } else {
            @Suppress("DEPRECATION")
            Notification.Builder(this).setContentTitle("أذكار مسلم").setContentText("الأذكار العائمة تعمل").setSmallIcon(android.R.drawable.ic_dialog_info).setContentIntent(pending).build()
        }
    }
    override fun onDestroy() {
        handler.removeCallbacks(ticker)
        removeOverlay()
        super.onDestroy()
    }
    override fun onBind(intent: Intent?): IBinder? = null
}

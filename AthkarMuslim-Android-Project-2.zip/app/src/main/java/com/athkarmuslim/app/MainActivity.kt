package com.athkarmuslim.app

import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.view.View
import android.widget.*
import android.graphics.Color
import android.graphics.Typeface

class MainActivity : Activity() {
    private val navy = Color.rgb(18, 34, 58)
    private val gold = Color.rgb(205, 169, 91)
    private val prefs by lazy { getSharedPreferences("athkar_settings", MODE_PRIVATE) }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        buildScreen()
    }

    private fun buildScreen() {
        val outer = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(24, 28, 24, 24)
            setBackgroundColor(Color.rgb(246, 243, 235))
        }
        val title = TextView(this).apply {
            text = "أذكار مسلم"
            textSize = 30f
            setTextColor(navy)
            typeface = Typeface.DEFAULT_BOLD
            gravity = Gravity.CENTER
        }
        outer.addView(title, LinearLayout.LayoutParams(-1, 70))
        val subtitle = TextView(this).apply {
            text = "رفيقك اليومي للذكر والطمأنينة"
            textSize = 16f
            setTextColor(Color.DKGRAY)
            gravity = Gravity.CENTER
        }
        outer.addView(subtitle, LinearLayout.LayoutParams(-1, 42))

        val card = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(18, 18, 18, 18)
            setBackgroundColor(Color.WHITE)
        }
        val heading = TextView(this).apply {
            text = "الأذكار العائمة"
            textSize = 21f
            typeface = Typeface.DEFAULT_BOLD
            setTextColor(navy)
        }
        card.addView(heading)
        val status = TextView(this).apply {
            text = if (prefs.getBoolean("enabled", false)) "الحالة: مفعّلة" else "الحالة: متوقفة"
            textSize = 15f
            setTextColor(Color.DKGRAY)
            setPadding(0, 10, 0, 10)
        }
        card.addView(status)
        val intervalLabel = TextView(this).apply {
            text = "مدة تكرار ظهور الذكر"
            textSize = 16f
            setTextColor(navy)
            setPadding(0, 12, 0, 6)
        }
        card.addView(intervalLabel)
        val spinner = Spinner(this)
        val options = listOf("كل دقيقة", "كل 5 دقائق", "كل 10 دقائق", "كل 15 دقيقة", "كل 30 دقيقة", "كل 60 دقيقة")
        spinner.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, options)
        val values = listOf(1, 5, 10, 15, 30, 60)
        val saved = prefs.getInt("interval", 10)
        spinner.setSelection(values.indexOf(saved).coerceAtLeast(0))
        spinner.onItemSelectedListener = object : android.widget.AdapterView.OnItemSelectedListener {
            override fun onNothingSelected(parent: android.widget.AdapterView<*>?) {}
            override fun onItemSelected(parent: android.widget.AdapterView<*>?, view: View?, position: Int, id: Long) {
                prefs.edit().putInt("interval", values[position]).apply()
                sendUpdate()
            }
        }
        card.addView(spinner, LinearLayout.LayoutParams(-1, 52))

        val permissionButton = makeButton("منح إذن الظهور فوق التطبيقات")
        permissionButton.setOnClickListener {
            if (!Settings.canDrawOverlays(this)) {
                startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
            } else Toast.makeText(this, "الإذن ممنوح بالفعل", Toast.LENGTH_SHORT).show()
        }
        card.addView(permissionButton, buttonParams())
        val startButton = makeButton("تشغيل الأذكار العائمة")
        startButton.setOnClickListener {
            if (!Settings.canDrawOverlays(this)) {
                Toast.makeText(this, "يرجى منح إذن الظهور أولاً", Toast.LENGTH_LONG).show()
                startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
            } else {
                prefs.edit().putBoolean("enabled", true).apply()
                startService(Intent(this, AthkarOverlayService::class.java).setAction(AthkarOverlayService.ACTION_START))
                status.text = "الحالة: مفعّلة"
            }
        }
        card.addView(startButton, buttonParams())
        val stopButton = makeButton("إيقاف الأذكار العائمة")
        stopButton.setOnClickListener {
            prefs.edit().putBoolean("enabled", false).apply()
            stopService(Intent(this, AthkarOverlayService::class.java))
            status.text = "الحالة: متوقفة"
        }
        card.addView(stopButton, buttonParams())
        outer.addView(card, LinearLayout.LayoutParams(-1, -2))

        val zikrTitle = TextView(this).apply {
            text = "ذكر اليوم"
            textSize = 21f
            typeface = Typeface.DEFAULT_BOLD
            setTextColor(navy)
            setPadding(0, 24, 0, 8)
        }
        outer.addView(zikrTitle)
        val zikr = TextView(this).apply {
            text = "سُبْحَانَ اللَّهِ وَبِحَمْدِهِ، سُبْحَانَ اللَّهِ الْعَظِيمِ"
            textSize = 20f
            gravity = Gravity.CENTER
            setTextColor(navy)
            setPadding(16, 24, 16, 24)
            setBackgroundColor(Color.WHITE)
        }
        outer.addView(zikr, LinearLayout.LayoutParams(-1, -2))
        val scroll = ScrollView(this)
        scroll.addView(outer)
        setContentView(scroll)
    }

    private fun makeButton(label: String) = Button(this).apply {
        text = label
        setTextColor(Color.WHITE)
        setBackgroundColor(navy)
        isAllCaps = false
    }
    private fun buttonParams() = LinearLayout.LayoutParams(-1, 54).apply { topMargin = 10 }
    private fun sendUpdate() {
        if (prefs.getBoolean("enabled", false) && Settings.canDrawOverlays(this)) {
            startService(Intent(this, AthkarOverlayService::class.java).setAction(AthkarOverlayService.ACTION_UPDATE))
        }
    }
    override fun onResume() {
        super.onResume()
    }
}
